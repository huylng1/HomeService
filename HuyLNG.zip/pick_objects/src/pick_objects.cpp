#include <ros/ros.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>

// Define a client for to send goal requests to the move_base server through a SimpleActionClient
typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;
// Define position pickup
float pos_x_pick = -5.55; // X-coordinate for the pickup position
float pos_y_pick = 3.93; // Y-coordinate for the pickup position
// Define position dropoff
float pos_x_dropoff = 1.7; // X-coordinate for the dropoff position
float pos_y_dropoff = -8.17; // Y-coordinate for the dropoff position

int main(int argc, char** argv)
{
  // Create a goal object for moving the robot using move_base action
  move_base_msgs::MoveBaseGoal robotPose;

  // Initialize the "pick_objects" node
  ros::init(argc, argv, "pick_objects");

  // Create an action client for move_base
  MoveBaseClient ac("move_base", true);

  // Wait for the move_base action server to initialize within 5 seconds
  while(!ac.waitForServer(ros::Duration(5.0)))
  {
    ROS_INFO("Waiting for the move_base action server to initialize");
  }
	
  // Set up the frame parameters for the goal
  robotPose.target_pose.header.frame_id = "map";
  robotPose.target_pose.header.stamp = ros::Time::now();
	
  // Define the initial position and orientation for the robot to reach
  robotPose.target_pose.pose.position.x = pos_x_pick;
  robotPose.target_pose.pose.position.y = pos_y_pick;
  robotPose.target_pose.pose.position.z = 0.0;
  robotPose.target_pose.pose.orientation.x = 0.0;
  robotPose.target_pose.pose.orientation.y = 0.0;
  robotPose.target_pose.pose.orientation.z = 0.0;
  robotPose.target_pose.pose.orientation.w = 1.0;
	
  // Send the goal position and orientation to the robot
  ac.sendGoal(robotPose);
	
  // Wait for the robot to reach the goal or for an infinite time
  ac.waitForResult();
	
  // Check if the robot successfully reached the pick-up zone
  if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
  {
    // Pause for 5 seconds before proceeding to the drop-off zone
    ros::Duration(5).sleep();

    // Update the frame parameters for the next goal
    robotPose.target_pose.header.frame_id = "map";
    robotPose.target_pose.header.stamp = ros::Time::now();

    // Define the position and orientation for the robot to reach at the drop-off zone
    robotPose.target_pose.pose.position.x = pos_x_dropoff;
    robotPose.target_pose.pose.position.y = pos_y_dropoff;
		
    // Send the goal position and orientation for the robot to reach
    ac.sendGoal(robotPose);
		
    // Wait for the robot to reach the goal or for an infinite time
    ac.waitForResult();
  }
  return 0;
}
