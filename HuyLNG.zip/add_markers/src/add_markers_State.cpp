#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include <nav_msgs/Odometry.h>
#include <math.h>

// Define positions for pick-up and drop-off zones
float pos_x_pick = -5.55; // X-coordinate for the pick-up position
float pos_y_pick = 3.93;  // Y-coordinate for the pick-up position

float pos_x_dropoff = 1.7;   // X-coordinate for the drop-off position
float pos_y_dropoff = -8.17; // Y-coordinate for the drop-off position

// Enum to represent the marker state (PICKUP or DROPOFF)
typedef enum
{
  PICKUP = 0,
  DROPOFF = 1,
} MarkerState;

// Function to spawn or hide a marker based on the given state and position
void spawnMarker(ros::Publisher& pub, MarkerState state, double posX, double posY)
{
  visualization_msgs::Marker marker;
  marker.header.frame_id = "map";
  marker.header.stamp = ros::Time::now();
  marker.ns = "basic_shapes";
  marker.id = 0;
  marker.type = visualization_msgs::Marker::CUBE;
  marker.action = state == PICKUP ? visualization_msgs::Marker::ADD : visualization_msgs::Marker::DELETE;
  marker.pose.position.x = posX;
  marker.pose.position.y = posY;
  marker.pose.position.z = 0;
  marker.pose.orientation.x = 0.0;
  marker.pose.orientation.y = 0.0;
  marker.pose.orientation.z = 0.0;
  marker.pose.orientation.w = 1.0;
  marker.scale.x = 0.5;
  marker.scale.y = 0.5;
  marker.scale.z = 0.5;
  marker.color.r = 0.0f;
  marker.color.g = 1.0f;
  marker.color.b = 1.0f;
  marker.color.a = 1.0;
  marker.lifetime = ros::Duration();

  // Log information about spawning or hiding the marker at the specified zone
  ROS_INFO_STREAM((state == PICKUP ? "Spawn" : "Hide") << " marker object at "
                                                       << (state == PICKUP ? "pick-up" : "drop-off") << " zone");

  pub.publish(marker);
  ros::Duration(5).sleep();  // Wait for 5 seconds
}

int main(int argc, char** argv)
{
  // Initialize ROS and create a node handle
  ros::init(argc, argv, "add_markers");
  ros::NodeHandle n;

  // Set the publishing rate
  ros::Rate r(1);

  // Create a publisher for the visualization marker
  ros::Publisher marker_pub = n.advertise<visualization_msgs::Marker>("visualization_marker", 1);

  // Set the initial state to PICKUP
  MarkerState state = PICKUP;

  // Main loop
  while (ros::ok())
  {
    // Wait for subscribers to the marker topic
    while (marker_pub.getNumSubscribers() < 1)
    {
      if (!ros::ok())
      {
        return 0;
      }
      ROS_WARN_ONCE("Please create a subscriber to the marker");
      sleep(1);
    }

    // Spawn or hide the marker based on the current state and zone position
    switch (state)
    {
      case PICKUP:
        spawnMarker(marker_pub, PICKUP, pos_x_pick, pos_y_pick);
        state = DROPOFF;
        break;
      case DROPOFF:
        spawnMarker(marker_pub, DROPOFF, pos_x_dropoff, pos_y_dropoff);
        break;
    }
  }

  return 0;
}
